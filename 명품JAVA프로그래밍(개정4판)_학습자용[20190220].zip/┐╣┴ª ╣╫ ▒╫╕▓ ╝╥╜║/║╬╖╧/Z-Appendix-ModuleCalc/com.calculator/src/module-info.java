/**
 * 
 */
/**
 * @author root
 *
 */
module com.calculator {
	exports lib;
}