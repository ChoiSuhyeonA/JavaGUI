/**
 * 
 */
/**
 * @author root
 *
 */
module com.goodcalc {
	requires com.calculator;
}