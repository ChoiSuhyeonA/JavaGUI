public interface IStack<T> {
	public T pop();
	public boolean push(T ob);
}
