
public class Command {
	public final static int FILE_NAME = 0x00;
	public final static int FILE_SIZE = 0x01;
	public final static int SEND_BEGIN = 0x02;
	public final static int SEND_END = 0x03;
}
